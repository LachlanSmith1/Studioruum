import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Resource
{
	
	//unique identifiers for the resource and attached user
	public int resourceID, userID;
	
	//the type of resource, being the subclass of this
	public String resourceType;
	
	//the name given to the resource (not neccessary)
	public String resourceName;
	
	//access level, which is private by default
	public String privacyLevel;
	
	
	public Resource(String name)
	{
		
		//DUMMY DATA FOR RESOURCES
		
		resourceID = 000001;
		userID = 101010;
		
		//ACTUAL DATA FOR ALL RESOURCES
		
		resourceName = name;
		
		resourceType = "null";
		privacyLevel = "private";
		
	}
	
	public static void main(String[] args)
	{
		
		Resource exResource = new Resource("exResource");
		
		exResource.writeResource();
		
	}

	public void writeResource()
	{
		
		//the name of the file which will be made at the current directory
		String name = resourceName + ".txt"; 
		
		try
		{
			
			//create a file object at the current directory
			File resourceFile = new File(name);
			
			boolean fileExists = resourceFile.createNewFile();
			
			//if the file didn't exist then creation was successful
			if (fileExists)
			{
				System.out.println("Resource File Created.");
			}
			else
			{
				System.out.println("Resource File Already Exists.");
			}
			
			//create a FileWriter object to write to the new 
			FileWriter resourceWriter = new FileWriter(name, false);
			
			//write the meta information to the file seperated by scarabs
			resourceWriter.write(" ¤¤ " + Integer.toString(resourceID) + " ¤ " + Integer.toString(userID) + " ¤ " + resourceType + " ¤ " + privacyLevel + " ¤¤ ");
			
			//close the writer once it's finished
			resourceWriter.close();
			
			
		}
		catch(IOException e)
		{
			
			e.printStackTrace();
			
		}
		
	}
	
}