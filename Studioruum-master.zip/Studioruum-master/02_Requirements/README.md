# Studioruum - Requirements

Information
-----------
The two types of users we want to deal with is Scholars (people who can use their account for personal reasons and to take part in classes) and Educators (people who can create classes which let them share their learning material to multiple people), so we can keep all of our documentation consistent.